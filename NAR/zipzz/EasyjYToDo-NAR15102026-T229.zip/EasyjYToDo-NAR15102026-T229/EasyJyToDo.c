//
// Created by clementzhao on 15/10/2026.
//


#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



typedef enum {
    ONGOING = 1,
    PENDING = 2
}Status;

typedef void (*MenuHandler)(void);

typedef struct {
    int optionsCount;
    char **statics;
    int *navToMenuIndex;
    MenuHandler *handlers;
}Menu;

typedef struct {
    int date;
    int month;
    int year;
}Deadline;

typedef struct {
    char *name;
    Status status;
    Deadline deadline;
}Job;

static Menu* menus;
static int menuCount;
static int userInputI;
static char *userInputS;
static Menu currentMenu;

static Job *jobs;
static int jobCount;
static int mainMenuId = 0;

static Menu constructMenu(int optCount, char** optionsString, MenuHandler handler) {
    Menu menu = (Menu){
    .optionsCount = optCount,
    .statics = optionsString,
    .handlers = &handler};
    menus[menuCount++] = menu;
    return menu;
}

static void printStatics() {
    for (int i = 0; i<currentMenu.optionsCount; i++) {
        printf("%d. %s\n", i+1, currentMenu.statics[i]);
    }
}

bool inputInt(uint32_t *assignTo, int bufferSize) {
    char buffer[bufferSize];
    if (fgets(buffer, bufferSize, stdin) != NULL) {
        errno = 0;
        char * endPtr;
        long val = strtol(buffer, &endPtr, 10);
        if (endPtr != buffer && *endPtr == '\0' || *endPtr == '\n') {
            *assignTo = (int)val;
            return true;
        }
        return false;
    }
}

static void checkInput(bool success) {
    if (!success) {
        printf("PLEASE INPUT A NUMBER");
    }
}

static int MAX = 0;
static int MIN = 1;

static void handleInputIntRange(int range[], char* inputPrint) {
    uint32_t tempUserInput = -1;
    printf("%s", inputPrint);
    bool inputSuccess = inputInt(&tempUserInput, userInputI);
    checkInput(inputSuccess);
    while (tempUserInput < range[MIN] || tempUserInput > range[MAX] || !inputSuccess) {
        if (inputSuccess) {
            printf("Input must be between %d - %d", range[MIN], range[MAX]);
            printf("%s", inputPrint);
            inputSuccess = inputInt(&tempUserInput, userInputI);
        }else {
            checkInput(inputSuccess);
        }
    }
}
static void handleInputStringRange(int range[], char* inputPrint) {
    char tempUserInput[1000];
    scanf("%s", tempUserInput);
    while (strlen(tempUserInput) < range[MIN] || strlen(tempUserInput) > range[MAX]) {
        printf("Input Length must be between %d - %d", range[MIN], range[MAX]);
        printf("%s", inputPrint);
        scanf("%s", tempUserInput);
    }
    memcpy(userInputS, tempUserInput, strlen(tempUserInput));
}

static void findJob() {

}

void printJobs(void) {
    for (int i = 0; i <jobCount; i++) {
        printf("  %d. %s", i+1, jobs[i].name);
    }
}

void navigate() {
    currentMenu = menus[currentMenu.navToMenuIndex[userInputI]];
}

void navigateTo(int i) {
    currentMenu = menus[i];
}

typedef enum {
    STRING,
    INTEGER,
}DataType;


void handleMultipleInput(const DataType dts[], int (*ranges)[2], void **varsPointer) {
    for (int i = 0; i<currentMenu.optionsCount; i++) {
        DataType dt = dts[i];
        switch (dt) {
            case STRING:
                handleInputStringRange(ranges[i], currentMenu.statics[i]);
                *(char **)varsPointer[i] = userInputS;
                break;
            case INTEGER:
                handleInputIntRange(ranges[i], currentMenu.statics[i]);
                *(int *)varsPointer[i] = userInputI;
                break;
        }
    }
}

void handleMainMenu(void) {
    printStatics();
    handleInputIntRange((int[]){1, 5}, "Choose ->");
    navigate();
}


void handleAddJob(void) {
    int arr[][2] = {
        {3, 100},
        {1, 2},
        {1, 31},
        {1, 12},
        {2000, 2100}
    };
    Job job = (Job){
    .name = "",
    .status = ONGOING,
    .deadline = (Deadline){
    .date = -1,
    .month = -1,
    .year = -1,}};


    void **pointers = calloc(3, sizeof(void*));
    void *pos = &job.name;
    pointers[1] = pos;
    pos = &job.status;
    pointers[2] = pos;
    pos = &job.deadline;
    pointers[3] = pos;

    handleMultipleInput(
        (DataType[]){STRING, INTEGER, INTEGER, INTEGER, INTEGER},
        arr,
        pointers)
    ;
    jobs[jobCount] = job;
    printf("JOB SUCCESFULLY RECORDED!");
    navigateTo(mainMenuId);
}

void handleUpdateJob(void) {

}



int main(int argc, char *argv[]) {
    menus = calloc(6, sizeof(Menu));
    jobs = calloc(100, sizeof(Job));
    char *mainMenuOptions[] = {"Add Job", "Update Status", "Search Job Name", "View All Jobs", "Exit"};
    constructMenu(5, &mainMenuOptions[0], handleMainMenu);
    char *createJobStatics[] = {
        "Job Name (3-100 characters) = ",
        "Select Status: \n1. ONGOING\n2. PENDING\nChoose =>",
        "Deadline date (1-31) = ", "Deadline month (1-12)", "Deadline year (2000-2100)",
        "JOB SUCCESS RECORDED"
    };

    constructMenu(5, &createJobStatics[0], handleAddJob);
    char *updateStatus[] = {
        "Which Job do you want to update the status of?\n-> "
    };
}

//push mid, sorted list, insert on the correct spot, ascending
